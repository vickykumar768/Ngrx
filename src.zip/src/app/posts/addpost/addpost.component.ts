import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Post } from '../../models/post.model';
import { Store } from '@ngrx/store';
import { AppState } from '../../store/app.state';
import { addPost } from '../state/post.action';

@Component({
  selector: 'app-addpost',
  templateUrl: './addpost.component.html',
  styleUrl: './addpost.component.css'
})
export class AddpostComponent implements OnInit {
FG!:FormGroup;

constructor(private store:Store<AppState>){

}
ngOnInit(): void {
  this.FG = new FormGroup({
    name:new FormControl(null, [Validators.required,Validators.minLength(5)]),
    title:new FormControl(null, [Validators.required,Validators.minLength(6)]),
  })
}
onAddPost(){
//   if(!this.FG.valid){
// return;
//   }
  console.log(this.FG.value);

  const post : Post={
    name:this.FG.value.name,
    title:this.FG.value.title,
  }

  this.store.dispatch(addPost({ post }));
}
}
