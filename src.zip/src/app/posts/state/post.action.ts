import { createAction, props } from "@ngrx/store";
import { Post } from "../../models/post.model";



export const add_post_action = '[post page] and post';

export const addPost = createAction(add_post_action,props<{post:Post}>())