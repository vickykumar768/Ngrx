import { Post } from "../../models/post.model"

export interface PostState{
    post:Post[];
}



export const initialState: PostState={
post:[
{id:'1', title:'UI Developer', name:'vicky kumar'},
{id:'2', title:'UI Developer', name:'Abhijeet'},
{id:'3', title:'frontend', name:'Deepak kumar'}
]
}