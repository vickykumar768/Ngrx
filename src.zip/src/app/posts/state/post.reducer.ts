import { State, createReducer, on } from "@ngrx/store";
import { initialState } from "./post.state";
import { addPost } from "./post.action";


const _postReducer= createReducer(initialState,on(addPost, (state,action)=>{
    let post = {...action.post};
    // action.post ( post is coming from action file )

    post.id= (state.post.length + 1).toString();
    return {
        ...state,
        post:[...state.post, post],
    }
}))

export function PostReducer(state:any, action:any){
    return _postReducer(state,action);

}