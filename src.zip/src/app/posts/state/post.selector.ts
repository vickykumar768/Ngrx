import { createFeatureSelector, createSelector } from "@ngrx/store";
import { PostState } from "./post.state";



const getPostState = createFeatureSelector<PostState>('postsName');
//('postsName') is just a name is same name of post reducer

export const getPost = createSelector(getPostState, state =>{
    // getPostState is same name of above createFeatureSelector
    return state.post;
})