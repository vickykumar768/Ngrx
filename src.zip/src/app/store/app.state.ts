import { counterState } from "../counter/state/counter.state";
import { counterReducer } from "../counter/state/state.reducer";
import { PostReducer } from "../posts/state/post.reducer";
import { PostState } from "../posts/state/post.state";

export interface AppState{
    reducerState:counterState,
    postState:PostState
}


export const appReducer = {
    reducerName:counterReducer,
    postsName:PostReducer,
}