import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { counterState } from '../state/counter.state';
import { changeName, customIncrement } from '../state/state.action';
import { getName } from '../state/counter.selector';
import { AppState } from '../../store/app.state';

@Component({
  selector: 'app-custom-counter-input',
  templateUrl: './custom-counter-input.component.html',
  styleUrl: './custom-counter-input.component.css'
})
export class CustomCounterInputComponent implements OnInit{
value!:number;
Name!:string;
constructor(private store:Store<AppState>){
// reducerName is same name from app module.ts file 
}

onAdd(){
  this.store.dispatch(customIncrement({ value : +this.value }));
  console.log('data', this.value);
}

changeName(){
this.store.dispatch(changeName());
}

ngOnInit(): void {
  this.store.select(getName).subscribe(date =>{
    console.log('name subscribe here ');
    this.Name = date;
  })
}
}
