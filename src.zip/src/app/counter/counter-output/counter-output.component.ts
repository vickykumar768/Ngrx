import { Component, Input, OnDestroy, OnInit,  } from '@angular/core';
import { Store } from '@ngrx/store';
import { counterState } from '../state/counter.state';
import { Subscription } from 'rxjs';
import { getCounter } from '../state/counter.selector';
import { AppState } from '../../store/app.state';

@Component({
  selector: 'app-counter-output',
  templateUrl: './counter-output.component.html',
  styleUrl: './counter-output.component.css'
})
export class CounterOutputComponent implements OnInit, OnDestroy{
  counter!:number;
  // @Input() counter!:number;

  counterSubscription!:Subscription;


constructor(private store:Store<AppState>){}
  // reducerName is the same as mention in appmodule.
  //counter:number is a initial state
// {counter:number} this tell the state type to refector this we have used counterState
  //  counterState 
  ngOnInit(): void {
   this.counterSubscription =  this.store.select(getCounter).subscribe(data=>{
    // getCounter coming from selector.ts file 
    console.log('counter subscribtion call ');
      this.counter = data;
    })
  }


  ngOnDestroy(): void {
    this.counterSubscription.unsubscribe();
  }
}
