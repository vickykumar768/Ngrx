import { Component, EventEmitter, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { Decrement, Reset, increment } from '../state/state.action';
import { counterState } from '../state/counter.state';
import { AppState } from '../../store/app.state';

@Component({
  selector: 'app-counter-button',
  templateUrl: './counter-button.component.html',
  styleUrl: './counter-button.component.css'
})
export class CounterButtonComponent {

  // @Output() increment = new EventEmitter<void>();
  // @Output() Decrement = new EventEmitter<void>();
  // @Output() Reset = new EventEmitter<void>();

  constructor(private store:Store<AppState>){}

  // reducerName is the same as mention in appmodule.
  //counter:number is a initial state

  ButtonIncrement(){
    // this.increment.emit();
    this.store.dispatch(increment());
    // increment() is coming from action 
  }
  ButtonDecrement(){
    // this.Decrement.emit();
    this.store.dispatch(Decrement());
  }
  ButtonReset(){
    // this.Reset.emit();
    this.store.dispatch(Reset());
  }


}
