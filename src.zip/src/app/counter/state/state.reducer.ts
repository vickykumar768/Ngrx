import { createReducer, on } from "@ngrx/store";
import { initialState } from "./counter.state";
import { Decrement, Reset, changeName, customIncrement, increment } from "./state.action";
import { state } from "@angular/animations";


const _counterReducer = createReducer(initialState, on(increment, (state)=>{
    return {
        ...state,
        counter: state.counter + 1,

        // counter is same name from intialState
    }
}), on(Decrement, (state)=>{
    return {
        ...state,
        counter : state.counter - 1,
    }
}),on(Reset, (state)=>{
    return {
        ...state,
        counter: 0,
    }
}), on(customIncrement,(state, action)=>{
    console.log(action);
    return {
        ...state,
        counter:state.counter + action.value,
    }
}), on(changeName,(state)=>{
    return{
        ...state,
       Name:'Changing name from vicky to Abhijeet'
    }
})
);

export function counterReducer(state:any, action:any){
    return _counterReducer(state, action);
}