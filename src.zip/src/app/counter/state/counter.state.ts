export interface counterState{
    counter:number;
    Name:string;
}
export const initialState:counterState = {
    counter:4,
    Name:'vicky',
}