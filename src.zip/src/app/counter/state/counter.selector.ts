import { createFeatureSelector, createSelector } from "@ngrx/store";
import { counterState } from "./counter.state";


const getCounterState = createFeatureSelector<counterState>('reducerName');

// reducerName same name from app.module.ts file

// below making indivisual all the preperty from the state so if you required only one state we can use. 
//we dont need to use all the state if not required 
export const getCounter = createSelector(getCounterState, (state)=>{
    return state.counter;
});

export const getName = createSelector(getCounterState, (state)=>{
    return state.Name;
});