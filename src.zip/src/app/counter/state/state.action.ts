import { createAction, props } from "@ngrx/store";



export const increment = createAction('increment');
export const Decrement = createAction('Decrement');
export const Reset = createAction('Reset');

export const customIncrement = createAction('customIncrement', props<{value:number}>());

export const changeName = createAction('changeName');

// props is parameter 